import {ChangeDetectorRef, Component, ElementRef, OnInit, ViewChild} from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { EmployeeService } from '../employee.service';
import { FormControl, FormGroupDirective, FormBuilder, FormGroup, NgForm, Validators } from '@angular/forms';

@Component({
  selector: 'app-employee-edit',
  templateUrl: './employee-edit.component.html',
  styleUrls: ['./employee-edit.component.css']
})
export class EmployeeEditComponent implements OnInit {

  employeeUpdateForm: FormGroup;
  _id:string='';
  UserName:string='';
  EmailId:string='';
  imagePath:string;
  Address:string;
  MobileNo:string;
  PinCode:string;
  isLoadingResults = false;


  constructor(private router: Router, private route: ActivatedRoute, private service: EmployeeService, private formBuilder: FormBuilder,
  private cd: ChangeDetectorRef) { }
  /*########################## File Upload ########################*/
  @ViewChild('fileInput') el: ElementRef;
  imageUrl: any = 'assets/no-img.jpg';
  editFile: boolean = true;
  removeUpload: boolean = false;

  ngOnInit() {
    // console.log('my id is getting inside edit '+this.route.snapshot.params['id']);
    this.getEmployee(this.route.snapshot.params['id']);
    this.employeeUpdateForm = this.formBuilder.group({
      'UserName': [null, Validators.required],
      'EmailId': [null, Validators.required],
      'imagePath': [null],
      'Address': [null, Validators.required],
      'MobileNo': [null, Validators.required],
      'PinCode': [null, Validators.required],
       file:[null]
    });

    this.uploadEditFile(event);

  }

  uploadEditFile(event) {
    let reader = new FileReader(); // HTML5 FileReader API
    let file = event.target.files[0];
    if (file.size > 25000) {
      alert("Sorry file size limit exceeded: Only image with size below 26kb are allowed!");
    } else {
      if (event.target.files && event.target.files[0]) {
        reader.readAsDataURL(file);

        // When file uploads set it to file formcontrol
        reader.onload = () => {
          this.imageUrl = reader.result;
          this.employeeUpdateForm.patchValue({
            file: reader.result
          });
          this.editFile = false;
          this.removeUpload = true;
        }
        // ChangeDetectorRef since file is loading outside the zone
        this.cd.markForCheck();
      }
    }
  }

  getEmployee(id) {
    this.service.getEmployee(id).subscribe(data => {
      this._id = data._id;
      this.imageUrl= 'http://localhost:50468/'+data.image;
      this.employeeUpdateForm.setValue({
        UserName: data.UserName,
        EmailId: data.EmailId,
        imagePath: data.image,
        Address: data.Address,
        MobileNo: data.MobileNo,
        PinCode: data.PinCode,
        file:null
      });
    });
  }

  // Function to remove uploaded file
  removeUploadedFile() {
    let newFileList = Array.from(this.el.nativeElement.files);
    this.imageUrl = 'assets/no-img.jpg';
    this.editFile = true;
    this.removeUpload = false;
    this.employeeUpdateForm.patchValue({
      file: [null]
    });
  }

  onFormEdit(form:NgForm) {
    console.log(form);
    this.isLoadingResults = true;
    this.service.updateEmployee(this._id, form)
      .subscribe(res => {
          let id = res;
          this.isLoadingResults = false;
          this.router.navigate(['/employee-details/', id._id]);
        }, (err) => {
          console.log(err);
          this.isLoadingResults = false;
        }
      );
  }

  employeeDetails() {
    // this.router.navigate(['/employee-details/', this._id]);
    this.router.navigate(['/employee-list']);
  }

}

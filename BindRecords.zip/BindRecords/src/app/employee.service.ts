import { Injectable } from '@angular/core';
import { Observable, of, throwError } from 'rxjs';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { catchError, tap, map } from 'rxjs/operators';
import { Employee } from './model/iuser';

const httpOptions = {
  headers: new HttpHeaders({'Content-Type': 'application/json'})
};
const apiAddUrl = "http://localhost:50468/Api/UserAPI/addEmployee";
const apiUpdateUrl = "http://localhost:50468/Api/UserAPI/updateEmployee";
const apiGetByIdUrl = "http://localhost:50468/Api/UserAPI/getEmployee";
const apiDeleteUrl = "http://localhost:50468/Api/UserAPI/deleteEmployee";
const apiAllUrl = "http://localhost:50468/Api/UserAPI/AllEmployee";

@Injectable()
// @Injectable({
//   providedIn: "root"
// })

export class EmployeeService {

  constructor(private http: HttpClient) { }

  AllUserDetails(): Observable<Employee[]> {
    return this.http.get<Employee[]>(apiAllUrl);
  }

  addEmployee(employee): Observable<Employee> {
    return this.http.post<Employee>(apiAddUrl, employee, httpOptions).pipe(
      tap((employ: Employee) => console.log(`added employee w/ id=${employ._id}`)),
      catchError(this.handleError<Employee>('addEmployee'))
    );
  }

  getEmployee(id: string): Observable<Employee> {
    const url = `${apiGetByIdUrl}/${id}`;
    return this.http.get<Employee>(url).pipe(
      tap(_ => console.log(`fetched employee id=${id}`)),
      catchError(this.handleError<Employee>(`getEmployee id=${id}`))
    );
  }

  deleteEmployee(id): Observable<Employee> {
    const url = `${apiDeleteUrl}/${id}`;
    return this.http.post<Employee>(url, httpOptions).pipe(
      tap(_ => console.log(`deleted employee id=${id}`)),
      catchError(this.handleError<Employee>('deleteEmployee'))
    );
  }

  updateEmployee (id, employee): Observable<Employee> {
    employee.updated_at = Date.now();
    const url = `${apiUpdateUrl}/${id}`;
    return this.http.put(url, employee, httpOptions).pipe(
      tap(_ => console.log(`updated employee id=${id}`)),
      catchError(this.handleError<any>('updateEmployee'))
    );
  }

  private handleError<T> (operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {

      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead

      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }
}

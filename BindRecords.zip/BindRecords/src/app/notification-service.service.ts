import { Injectable } from '@angular/core';
import { Observable, of, throwError } from 'rxjs';
import { Subject } from 'rxjs';

@Injectable()
export class NotificationServiceService {

  notification = {
    title: '',
    message: ''
  };

  private subject = new Subject<any>();

  constructor() { }

  setNotification(title, message) {
    this.subject.next(
      this.notification = {
        title: title,
        message: message
      }
    );
  }

  getNotification(): Observable<any> {
    return this.subject.asObservable();
  }

}

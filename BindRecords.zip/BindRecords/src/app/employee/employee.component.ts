import { Component, OnInit, ViewChild } from '@angular/core';
import { Employee } from '../model/iuser';
import { Router, ActivatedRoute } from '@angular/router';
import { MatTableDataSource, MatSort, MatPaginator } from '@angular/material';
import { EmployeeService } from '../employee.service';
import { DatePipe } from '@angular/common';
import * as moment from 'moment';
import {FormControl, FormGroup, FormBuilder, FormArray} from '@angular/forms';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {
  myForm: FormGroup;
  subUrl: any = 'assets/submit-button-png-4.jpg';
  dataSource = null;
  isLoadingResults = true;
  displayedColumns: string[] = ['check','Image','UserName', 'EmailId', 'Gender','Address','MobileNo','created','Action'];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  pipe: DatePipe;
  filterForm = new FormGroup({
    fromDate: new FormControl(),
    toDate: new FormControl(),
  });


  get fromDate() { return this.filterForm.get('fromDate'); }
  get toDate() { return this.filterForm.get('toDate'); }

  constructor(private router: Router, private route: ActivatedRoute,private service: EmployeeService,private fb: FormBuilder){
  }


  ngOnInit() {

      this.myForm = this.fb.group({
      userid: this.fb.array([])
    });
    // console.log("Retrieving contacts...");
    this.service.AllUserDetails().subscribe(
      data => {
        // console.log("data retrieved:\n" + data);
        this.dataSource = new MatTableDataSource<Employee>(data);
        this.dataSource.sort = this.sort;
        this.dataSource.paginator = this.paginator;
        this.dataSource.data.forEach(row => row.editing = false);
        this.isLoadingResults = false;


        this.pipe = new DatePipe('en');
        // console.log(this.dataSource.filterPredicate);
        const defaultPredicate=this.dataSource.filterPredicate;
        console.log(defaultPredicate);
        this.dataSource.filterPredicate = (data, filter) =>{
          const formatted=this.pipe.transform(data.created,'yyyy-MM-dd');
          return formatted.indexOf(filter) >= 0 || defaultPredicate(data,filter) ;
        }
      },
      error => console.log(error));
    this.isLoadingResults = false;
  }

  applyFilter(filterValue: string) {
     this.dataSource.filter = filterValue.trim().toLowerCase();
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  stringAsDate(dateStr: string) {
    return new Date(dateStr);
  }


  getDateRange(value) {
    // getting date from calendar
    const fromDate2 = value.fromDate;
    const toDate2 = value.toDate;
    const fromDate =this.pipe.transform(fromDate2,'yyyy-MM-dd');
    const toDate =this.pipe.transform(toDate2,'yyyy-MM-dd');
    this.dataSource = this.dataSource.data.filter(e=>e.created > fromDate && e.created < toDate).sort((a, b) => a.created - b.created) ;
  }

  deleteEmployee(id) {
    this.isLoadingResults = true;
    this.service.deleteEmployee(id)
      .subscribe(res => {
          this.isLoadingResults = false;
          this.router.navigate(['/employee-list/']);
        }, (err) => {
          console.log(err);
          this.isLoadingResults = false;
        }
      );
  }

  changeValue(user:string, isChecked: boolean) {
    const userFormArray = <FormArray>this.myForm.controls.userid;

    if(isChecked) {
      userFormArray.push(new FormControl(user));
      console.log(userFormArray);
    } else {
      let index = userFormArray.controls.findIndex(x => x.value === user)
      console.log(index);
      // userFormArray.removeAt(index);
    }
  }

}

import {Component, OnInit, ChangeDetectorRef, ElementRef, ViewChild} from '@angular/core';
import { Router } from '@angular/router';
import { EmployeeService } from '../employee.service';
import { FormControl, FormGroupDirective, FormBuilder, FormGroup, NgForm, Validators } from '@angular/forms';

@Component({
  selector: 'app-employee-add',
  templateUrl: './employee-add.component.html',
  styleUrls: ['./employee-add.component.css']
})
export class EmployeeAddComponent implements OnInit {

  employeeForm: FormGroup;
  UserName:string='';
  EmailId:string='';
  Gender:string;
  Address:string;
  MobileNo:string;
  PinCode:string;
  image:string;
  isLoadingResults = false;

  event = {
    gender: "Select Gender"
  }

  constructor(private router: Router, private service: EmployeeService, private formBuilder: FormBuilder,
              private cd: ChangeDetectorRef) { }

  /*########################## File Upload ########################*/
  @ViewChild('fileInput') el: ElementRef;
  imageUrl: any = 'assets/no-img.jpg';
  editFile: boolean = true;
  removeUpload: boolean = false;

  ngOnInit() {
    this.employeeForm = this.formBuilder.group({
      'UserName' : [null, Validators.required],
      'EmailId' : [null, Validators.required],
      'Gender' : [null, Validators.required],
      'Address' : [null, Validators.required],
      'MobileNo' : [null, Validators.required],
      'PinCode' : [null, Validators.required],
      file: [null]
    });
  }


  uploadFile(event) {
    let reader = new FileReader(); // HTML5 FileReader API
    let file = event.target.files[0];
    if (file.size > 25000) {
      alert("Sorry file size limit exceeded: Only image with size below 26kb are allowed!");
    } else {
      if (event.target.files && event.target.files[0]) {
        reader.readAsDataURL(file);

        // When file uploads set it to file formcontrol
        reader.onload = () => {
          this.imageUrl = reader.result;
          this.employeeForm.patchValue({
            file: reader.result
          });
          this.editFile = false;
          this.removeUpload = true;
        }
        // ChangeDetectorRef since file is loading outside the zone
        this.cd.markForCheck();
      }
    }
  }
  // Function to remove uploaded file
  removeUploadedFile() {
    let newFileList = Array.from(this.el.nativeElement.files);
    this.imageUrl = 'assets/no-img.jpg';
    this.editFile = true;
    this.removeUpload = false;
    this.employeeForm.patchValue({
      file: [null]
    });
  }

  onFormSubmit(form:NgForm) {
    // console.log(this.employeeForm.value);
    this.isLoadingResults = true;
    this.service.addEmployee(form)
      .subscribe(res => {
        let id = res;
        console.log('my new id is '+id._id);
        this.isLoadingResults = false;
        this.router.navigate(['/employee-details/', id._id]);
      }, (err) => {
        console.log(err);
        this.isLoadingResults = false;
      });
  }


}

export interface Employee {
  _id: string;
  UserName: string;
  EmailId: string;
  Gender: string;
  Address: string;
  MobileNo: string;
  PinCode: string;
  updated_at: Date;
  image: string;
  created: Date;
}


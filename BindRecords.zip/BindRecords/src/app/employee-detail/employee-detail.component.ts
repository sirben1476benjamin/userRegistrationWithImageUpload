import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { EmployeeService } from '../employee.service';
import { Employee } from '../model/iuser';

@Component({
  selector: 'app-employee-detail',
  templateUrl: './employee-detail.component.html',
  styleUrls: ['./employee-detail.component.css']
})
export class EmployeeDetailComponent implements OnInit {
  imageUrl: any = 'assets/no-img.jpg';
  employee: Employee = {_id: '', UserName: '', EmailId: '', Gender: '', Address:'', MobileNo:'',PinCode:'', updated_at: null,image:'',
    created: null };
  isLoadingResults = true;
  constructor(private route: ActivatedRoute, private service: EmployeeService, private router: Router) { }

  ngOnInit() {
    this.getEmployeeDetails(this.route.snapshot.params['id']);
  }

  getEmployeeDetails(id) {
    this.service.getEmployee(id)
      .subscribe(data => {
        this.employee = data;
        this.imageUrl = 'http://localhost:50468/'+this.employee.image;
        console.log(this.employee.image);
        this.isLoadingResults = false;
      });
  }

  deleteEmployee(id) {
    this.isLoadingResults = true;
    this.service.deleteEmployee(id)
      .subscribe(res => {
          this.isLoadingResults = false;
          this.router.navigate(['/employee-list']);
        }, (err) => {
          console.log(err);
          this.isLoadingResults = false;
        }
      );
  }

  stringAsDate(dateStr: string) {
    return new Date(dateStr);
  }

}
